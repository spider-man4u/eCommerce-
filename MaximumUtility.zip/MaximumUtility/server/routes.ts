import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertProductSchema } from "@shared/schema";

// Sample products data
const sampleProducts = [
  {
    name: "Modern Desk Lamp",
    description: "Sleek and minimalist desk lamp with adjustable brightness and color temperature. Perfect for your workspace.",
    price: 129.99,
    imageUrl: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&auto=format&fit=crop&q=60",
    category: "Lighting",
    stock: 50
  },
  {
    name: "Ergonomic Chair",
    description: "Premium office chair with advanced ergonomic features for maximum comfort during long work sessions.",
    price: 599.99,
    imageUrl: "https://images.unsplash.com/photo-1505797149-35ebcb05a6fd?w=800&auto=format&fit=crop&q=60",
    category: "Furniture",
    stock: 20
  },
  {
    name: "Smart Watch Pro",
    description: "Advanced smartwatch with health tracking, notifications, and a sleek design.",
    price: 299.99,
    imageUrl: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=60",
    category: "Electronics",
    stock: 100
  },
  {
    name: "Wireless Earbuds",
    description: "Premium wireless earbuds with noise cancellation and crystal clear sound quality.",
    price: 199.99,
    imageUrl: "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=800&auto=format&fit=crop&q=60",
    category: "Electronics",
    stock: 75
  },
  {
    name: "Designer Backpack",
    description: "Stylish and functional backpack with multiple compartments and water-resistant material.",
    price: 149.99,
    imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=60",
    category: "Accessories",
    stock: 30
  },
  {
    name: "Premium Coffee Maker",
    description: "Advanced coffee machine with precision brewing and temperature control.",
    price: 399.99,
    imageUrl: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&auto=format&fit=crop&q=60",
    category: "Appliances",
    stock: 25
  },
  {
    name: "Mechanical Keyboard",
    description: "Professional mechanical keyboard with customizable RGB lighting and premium switches.",
    price: 159.99,
    imageUrl: "https://images.unsplash.com/photo-1595225476474-87563907a212?w=800&auto=format&fit=crop&q=60",
    category: "Electronics",
    stock: 40
  },
  {
    name: "Minimalist Wall Clock",
    description: "Modern wall clock with a sleek design and silent movement mechanism.",
    price: 79.99,
    imageUrl: "https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=800&auto=format&fit=crop&q=60",
    category: "Home Decor",
    stock: 60
  }
];

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Products
  app.get("/api/products", async (_req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get("/api/products/:id", async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) return res.sendStatus(404);
    res.json(product);
  });

  app.post("/api/products", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);

    const parseResult = insertProductSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }

    const product = await storage.createProduct(parseResult.data);
    res.status(201).json(product);
  });

  app.patch("/api/products/:id", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);

    const product = await storage.updateProduct(Number(req.params.id), req.body);
    if (!product) return res.sendStatus(404);
    res.json(product);
  });

  app.delete("/api/products/:id", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);

    const success = await storage.deleteProduct(Number(req.params.id));
    if (!success) return res.sendStatus(404);
    res.sendStatus(204);
  });

  // Orders
  app.get("/api/orders", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const orders = await storage.getOrders(req.user.id);
    res.json(orders);
  });

  app.post("/api/orders", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const order = await storage.createOrder({
      userId: req.user.id,
      status: "pending",
      total: req.body.total,
      createdAt: new Date().toISOString(),
    });

    for (const item of req.body.items) {
      await storage.createOrderItem({
        orderId: order.id,
        productId: item.productId,
        quantity: item.quantity,
        price: item.price,
      });
    }

    res.status(201).json(order);
  });

  const httpServer = createServer(app);
  return httpServer;
}