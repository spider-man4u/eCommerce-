import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShoppingCart, User, Search, Sun, Moon } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";

interface NavbarProps {
  onCartClick: () => void;
  onSearch: (query: string) => void;
}

export function Navbar({ onCartClick, onSearch }: NavbarProps) {
  const { user, logoutMutation } = useAuth();
  const { items } = useCart();

  return (
    <nav className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <div className="flex items-center gap-2">
              <img src="https://i.ibb.co/Q7YrW1zr/IMG-20250209-043711.jpg" alt="ZRYPN Logo" className="h-12 w-auto" />
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                ZRYPN
              </span>
            </div>
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <Link href="/" className="hover:text-primary transition-colors">Products</Link>
            {user?.isAdmin && (
              <Link href="/admin" className="hover:text-primary transition-colors">Admin</Link>
            )}
          </nav>
        </div>

        <div className="flex-1 px-4">
          <div className="relative max-w-sm">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search products..."
              className="pl-8 bg-background/50"
              onChange={(e) => onSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center justify-end space-x-4">
          <nav className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="hover:bg-primary/10"
              onClick={() => document.documentElement.classList.toggle('dark')}
            >
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-transform dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-transform dark:rotate-0 dark:scale-100" />
            </Button>
            {user ? (
              <>
                <Button
                  variant="ghost"
                  className="relative hover:bg-primary/10"
                  onClick={onCartClick}
                >
                  <ShoppingCart className="h-5 w-5" />
                  {items.length > 0 && (
                    <span className="absolute -right-1 -top-1 h-4 w-4 rounded-full bg-primary text-xs text-primary-foreground flex items-center justify-center">
                      {items.length}
                    </span>
                  )}
                </Button>
                <Button
                  variant="ghost"
                  className="hover:bg-primary/10"
                  asChild
                >
                  <Link href="/profile">
                    <User className="h-5 w-5 mr-2" />
                    {user.username}
                  </Link>
                </Button>
              </>
            ) : (
              <Button asChild variant="default" className="bg-primary hover:bg-primary/90">
                <Link href="/auth">Login</Link>
              </Button>
            )}
          </nav>
        </div>
      </div>
    </nav>
  );
}