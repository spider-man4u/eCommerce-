import { Product } from "@shared/schema";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { motion } from "framer-motion";
import { ShoppingCart, Package2, Tag } from "lucide-react";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl group bg-black/40 backdrop-blur-sm border-primary/10">
      <div className="relative aspect-[4/3] overflow-hidden">
        <motion.img
          src={product.imageUrl}
          alt={product.name}
          className="h-full w-full object-cover"
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.3 }}
        />
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center">
            <p className="text-lg font-semibold text-muted-foreground">Out of Stock</p>
          </div>
        )}
        <div className="absolute top-4 right-4">
          <motion.div
            className="bg-primary/90 text-primary-foreground px-4 py-1.5 rounded-full text-sm font-medium"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            ${product.price.toFixed(2)}
          </motion.div>
        </div>
      </div>
      <CardContent className="p-6">
        <div className="space-y-2">
          <motion.h3 
            className="font-semibold text-lg text-card-foreground group-hover:text-primary transition-colors"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            {product.name}
          </motion.h3>
          <motion.p 
            className="text-sm text-muted-foreground line-clamp-2"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            {product.description}
          </motion.p>
        </div>
        <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Package2 className="h-4 w-4 text-primary" />
            <span>{product.stock} in stock</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Tag className="h-4 w-4 text-primary" />
            <span className="capitalize">{product.category}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-6 pt-0">
        <Button
          className="w-full bg-primary/90 hover:bg-primary transition-colors group"
          onClick={() => addItem(product)}
          disabled={product.stock === 0}
        >
          <ShoppingCart className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform" />
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
}