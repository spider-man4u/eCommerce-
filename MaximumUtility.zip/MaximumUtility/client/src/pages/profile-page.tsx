import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { 
  User, 
  ShoppingBag, 
  Clock,
  Settings,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();

  const menuItems = [
    { icon: <ShoppingBag className="w-5 h-5" />, label: "Orders" },
    { icon: <Clock className="w-5 h-5" />, label: "Order History" },
    { icon: <Settings className="w-5 h-5" />, label: "Settings" },
    { icon: <LogOut className="w-5 h-5" />, label: "Logout", onClick: () => logoutMutation.mutate() }
  ];

  return (
    <div className="min-h-screen py-24">
      <div className="container max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          {/* Profile Header */}
          <Card className="overflow-hidden border-primary/10 bg-black/40 backdrop-blur-sm">
            <div className="h-32 bg-gradient-to-r from-primary/20 to-primary/5" />
            <CardHeader className="relative">
              <div className="absolute -top-16 left-6">
                <motion.div
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="rounded-full bg-background/95 p-2 backdrop-blur supports-[backdrop-filter]:bg-background/60"
                >
                  <div className="rounded-full bg-primary/10 p-6">
                    <User className="h-12 w-12 text-primary" />
                  </div>
                </motion.div>
              </div>
              <div className="pt-16">
                <CardTitle className="text-2xl font-bold">
                  {user?.username}
                </CardTitle>
                <p className="text-muted-foreground mt-2">
                  Member since {new Date().toLocaleDateString()}
                </p>
              </div>
            </CardHeader>
          </Card>

          {/* Menu Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {menuItems.map((item, index) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-4 p-6 bg-black/40 backdrop-blur-sm border border-primary/10 hover:bg-primary/5 hover:border-primary/20 transition-all group"
                  onClick={item.onClick}
                >
                  <div className="p-2 rounded-full bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">
                    {item.icon}
                  </div>
                  <span className="font-medium">{item.label}</span>
                </Button>
              </motion.div>
            ))}
          </div>

          {/* Stats Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-4"
          >
            {[
              { label: "Total Orders", value: "12" },
              { label: "Wishlist Items", value: "5" },
              { label: "Reviews", value: "8" },
            ].map((stat, index) => (
              <Card key={stat.label} className="border-primary/10 bg-black/40 backdrop-blur-sm">
                <CardContent className="p-6">
                  <p className="text-muted-foreground">{stat.label}</p>
                  <p className="text-3xl font-bold text-primary mt-2">{stat.value}</p>
                </CardContent>
              </Card>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
