import { ProductCard } from "@/components/product-card";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { Shield, CreditCard, Sparkles } from "lucide-react";

interface HomePageProps {
  searchQuery: string;
}

const features = [
  {
    icon: <Shield className="h-6 w-6" />,
    title: "Premium Quality",
    description: "Carefully curated selection of luxury items",
  },
  {
    icon: <CreditCard className="h-6 w-6" />,
    title: "Secure Payments",
    description: "Safe and encrypted transaction processing",
  },
  {
    icon: <Sparkles className="h-6 w-6" />,
    title: "Exclusive Deals",
    description: "Special offers for our valued customers",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
  },
};

export default function HomePage({ searchQuery }: HomePageProps) {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const filteredProducts = products?.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const featuredProduct = products?.[0];

  return (
    <div className="min-h-screen">
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-background">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:60px_60px]" />
        <div className="container py-24 relative">
          <motion.div 
            className="text-center space-y-8 relative z-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="mx-auto w-fit px-4 py-1 rounded-full border border-primary/20 bg-primary/10 text-primary"
            >
              Premium Shopping Experience
            </motion.div>

            <motion.h1 
              className="text-4xl md:text-7xl font-bold tracking-tight bg-gradient-to-br from-white via-primary-foreground to-primary/50 bg-clip-text text-transparent"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              Discover Luxury at<br/>Your Fingertips
            </motion.h1>

            <motion.p 
              className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              Experience a curated collection of premium products designed to elevate your lifestyle
            </motion.p>

            <motion.div 
              className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
            >
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  className="flex flex-col items-center p-8 rounded-2xl bg-black/40 backdrop-blur-sm border border-primary/10 hover:border-primary/30 transition-colors"
                  whileHover={{ scale: 1.05, transition: { duration: 0.2 } }}
                >
                  <div className="p-3 rounded-full bg-primary/20 text-primary">
                    {feature.icon}
                  </div>
                  <h3 className="mt-4 font-semibold text-lg">{feature.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground text-center">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Featured Product Section */}
      {featuredProduct && (
        <div className="container py-24">
          <motion.div
            className="relative overflow-hidden rounded-3xl"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/5" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-8 md:p-12">
              <motion.div
                className="space-y-6"
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
                  Featured Product
                </h2>
                <h3 className="text-2xl font-semibold text-primary">
                  {featuredProduct.name}
                </h3>
                <p className="text-lg text-muted-foreground">
                  {featuredProduct.description}
                </p>
                <div className="text-2xl font-bold text-primary">
                  ${featuredProduct.price.toFixed(2)}
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
              >
                <img
                  src={featuredProduct.imageUrl}
                  alt={featuredProduct.name}
                  className="w-full h-[400px] object-cover rounded-2xl shadow-2xl"
                />
              </motion.div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Products Grid */}
      <div className="container py-24">
        {searchQuery && (
          <motion.h2
            className="text-2xl font-semibold mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            Search Results for "{searchQuery}"
          </motion.h2>
        )}
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {isLoading
            ? Array.from({ length: 8 }).map((_, i) => (
                <motion.div 
                  key={i} 
                  variants={itemVariants}
                  className="space-y-4"
                >
                  <Skeleton className="h-[300px] w-full rounded-xl" />
                  <Skeleton className="h-4 w-[250px]" />
                  <Skeleton className="h-4 w-[200px]" />
                </motion.div>
              ))
            : filteredProducts?.map((product) => (
                <motion.div
                  key={product.id}
                  variants={itemVariants}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
        </motion.div>
        {filteredProducts?.length === 0 && (
          <motion.p
            className="text-center text-muted-foreground mt-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            No products found matching your search.
          </motion.p>
        )}
      </div>
    </div>
  );
}